package com.example.new_drc_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
