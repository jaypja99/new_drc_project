import 'package:flutter/material.dart';

class LoginValidationDemo extends StatefulWidget {
  const LoginValidationDemo({Key? key}) : super(key: key);

  @override
  _LoginValidationDemoState createState() => _LoginValidationDemoState();
}

class _LoginValidationDemoState extends State<LoginValidationDemo> {

  TextEditingController emailController= TextEditingController();
  FocusNode emailfocus= FocusNode();
  FocusNode passwordfocus= FocusNode();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
        backgroundColor: Colors.blueGrey,
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 30, left: 20,right: 20),
        child: Form(
          key: _formKey ,
          child: Column(
            children:  [
                 TextFormField(
                   focusNode: emailfocus,
                   controller: emailController,
                   textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: "Enter your Email",
                    labelText: "Email Address",
                  ),
                   validator: (value){
                     bool emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value.toString());
                     if(value.toString().isEmpty || emailValid==false){

                       return "Password must contain at least 6 character";

                     }
                     return null;


                   },
                ),
                const SizedBox(height: 20),
                 TextFormField(
                  focusNode: passwordfocus,
                  textInputAction: TextInputAction.done,
                  obscureText: true,
                  decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "Enter your Password",
                      labelText: "Password",

                    ),
                   validator: (value){
                       if(value.toString().length < 6 || value.toString().isEmpty){

                       return "Enter you email perfecty";

                     }
                     return null;
                   },
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(

                        onPressed: ()
                        {
                          if(_formKey.currentState!.validate()){

                          }
                        },
                        child: Text("Login", style: TextStyle(fontSize: 15),)
                    ),
                  ),
                )
            ],
          ),
        ),
      ),
    );
  }

}

