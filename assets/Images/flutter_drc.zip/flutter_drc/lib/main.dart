import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_drc/Pages/AlertDialogDemo.dart';
import 'package:flutter_drc/Pages/BottomSheetDemo.dart';
import 'package:flutter_drc/Pages/DateTimeDemo.dart';
import 'package:flutter_drc/Pages/GridViewDemo.dart';
import 'package:flutter_drc/Pages/ListViewDemo.dart';
import 'package:flutter_drc/Pages/LoginValidationDemo.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: "Drc Systems",
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text("Drc Systems"), backgroundColor: Colors.blueGrey),
      drawer: _drawer(),
      bottomNavigationBar: _bottomnav(),
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(22),
              child: Center(
                  child: Text(
                "Topic 1 Bottom Navigation",
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              )),
            ),
            Center(
                child: Text(
              "Selected Index :" + "  " + _selectedIndex.toString(),
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ))
          ],
        ),
      ),
    );
  }

  Widget _drawer() {
    return Drawer(
      child: ListView(
        children: [
          DrawerHeader(
              padding: EdgeInsets.zero,
              child: Container(
                padding: EdgeInsets.all(10),
                width: double.infinity,
                height: double.infinity,
                color: Colors.blueGrey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: const [
                    Text(
                      "DRC Systems Flutter Topics",
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white),
                    )
                  ],
                ),
              )),
          Padding(
            padding: const EdgeInsets.only(left: 8, right: 8),
            child: Card(
              shadowColor: Colors.blueGrey,
              child: ListTile(
                title: Text("AlertDialog Box", style: TextStyle(fontSize: 18)),
                leading: Icon(Icons.topic),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => new AlertDialogDemo()));
                },
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.only(left: 8, right: 8),
            child: Card(
              child: ListTile(
                title: Text("DateTime Picker", style: TextStyle(fontSize: 18)),
                leading: Icon(Icons.topic),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => new DateTimeDemo()));
                },
              ),
            ),
          ),


          Padding(
            padding: const EdgeInsets.only(left: 8, right: 8),
            child: Card(
              child: ListTile(
                title: Text("Bottom Sheet", style: TextStyle(fontSize: 18)),
                leading: Icon(Icons.topic),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => new BottomSheetDemo()));
                },
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.only(left: 8, right: 8),
            child: Card(
              child: ListTile(
                title: Text("ListView", style: TextStyle(fontSize: 18)),
                leading: Icon(Icons.topic),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => new ListViewDemo()));
                },
              ),
            ),
          ),

           Padding(
            padding: EdgeInsets.only(left: 8, right: 8),
            child: Card(
              child: ListTile(
                title: Text("GridView Demo", style: TextStyle(fontSize: 18)),
                leading: Icon(Icons.topic),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => new GridViewDemo()));
                },
              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.only(left: 8, right: 8),
            child: Card(
              child: ListTile(
                title: Text("Login With Validation", style: TextStyle(fontSize: 18)),
                leading: Icon(Icons.topic),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => new LoginValidationDemo()));
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bottomnav() {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      selectedItemColor: Colors.deepPurple,
      unselectedItemColor: Colors.blueGrey,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(
            icon: Icon(Icons.verified_user), label: "Verify"),
        BottomNavigationBarItem(icon: Icon(Icons.bookmark), label: "Bookmarks"),
        BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Setting"),
      ],
      currentIndex: _selectedIndex,
      onTap: _onItemTapped,
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
}
