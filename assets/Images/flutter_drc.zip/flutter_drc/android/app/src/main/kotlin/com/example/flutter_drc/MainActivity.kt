package com.example.flutter_drc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
